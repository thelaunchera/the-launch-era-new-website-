/* Client-facing Knockout Deli website concept. No owner/Admin Panel shipped here. */
(() => {
  'use strict';
  const DOORDASH_URL = 'https://www.doordash.com/store/42538456';
  const root = document.documentElement;
  const $ = (selector, parent=document) => parent.querySelector(selector);
  const $$ = (selector, parent=document) => [...parent.querySelectorAll(selector)];
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const defaultData = {
    menu: [
      {id:'jab',name:'The Jab',category:'Main Event',price:25,description:'A featured selection from the Main Event lineup. Please confirm the official item description before ordering.',image:'./assets/02-menu-spread.webp',available:true},
      {id:'body',name:'The Body Shot',category:'Main Event',price:27,description:'One of Knockout Deli’s main-event favorites. See the official menu for current ingredients.',image:'./assets/01-hero-pastrami.webp',available:true},
      {id:'ribeye',name:'Rib-Eye Cheesesteak',category:'Main Event',price:18,description:'A cheesesteak classic. Prices and options shown are for concept review and should be confirmed.',image:'./assets/06-cheesesteak-grill.webp',available:true},
      {id:'pound',name:'Pound For Pound',category:'Main Event',price:20,description:'A favorite from the lineup. Confirm its full ingredients on the official menu.',image:'./assets/04-customer-experience.webp',available:true},
      {id:'breakfast',name:'Breakfast Lineup',category:'Breakfast',price:null,description:'Explore the morning choices from Knockout Deli. See the official menu for items and prices.',image:'./assets/05-breakfast-sandwich.webp',available:true},
      {id:'ringside',name:'Ringside Favorites',category:'Ringside Favorites',price:null,description:'A preview of deli-side favorites. Find the current selection on their official menu.',image:'./assets/02-menu-spread.webp',available:true},
      {id:'takehome',name:'Take Home',category:'Take Home',price:null,description:'Take your favorites with you. Check the official menu for current choices.',image:'./assets/07-order-online.webp',available:true}
    ],
    events: [],
    truck: {location:'',hours:''}
  };
  const phrases = {
    en: {
      navMenu:'THE MENU',navEvents:'UPCOMING STOPS',navCatering:'BOOK THE TRUCK',navFind:'FIND US',orderButton:'ORDER ON DOORDASH',
      heroLine1:'NEW YORK',heroLine2:'DELI.',heroLine3:'ON WHEELS.',heroDescription:'New York deli favorites, rolling through South Florida. Big sandwiches, bold flavor, and a new stop to discover.',heroBottom:'REAL DELI ENERGY, WHEREVER WE PARK.',exploreMenu:'EXPLORE THE MENU',findTruck:'FIND THE TRUCK',photoPreview:'WEBSITE CONCEPT PHOTOGRAPHY',
      menuKicker:'THE GOOD STUFF',menuTitle:'THE MAIN<br><i>EVENT.</i>',menuIntro:'Deli favorites, built with real character. See a taste of what’s on the menu.',menuNote:'Concept preview · Current menu and pricing subject to confirmation.',filterAll:'ALL FAVORITES',filterMain:'MAIN EVENT',filterBreakfast:'BREAKFAST',filterRingside:'RINGSIDE FAVORITES',menuFooter:'HUNGRY? WE KNOW A PLACE.',
      eventsKicker:'ON THE MOVE',eventTitle:'NOT JUST A<br>FOOD TRUCK.<br><i>A GOOD TIME.</i>',eventsCopy:'Pop-ups, markets, and neighborhood gatherings. When we’re rolling into your area, you’ll find it right here.',seeLocation:'SEE OUR LOCATION',upcomingLabel:'UPCOMING APPEARANCES',eventFoot:'CHECK BACK FOR OUR NEXT STOP',
      locationKicker:'FIND YOUR NEXT BITE',locationHeading:"WHERE<br>WE'LL BE<span class='heading-period'>.</span>",locationCopy:'The truck moves. Good food follows. Check the latest location details before heading out.',currentStop:'CURRENT STOP',locationButton:'GET LATEST UPDATES',
      cateringKicker:'BRING THE HEAT',cateringTitle:"LET'S MAKE<br>IT <i>AN EVENT.</i>",cateringIntro:'Private gatherings, company lunches, festivals, and community days. Have an event in mind? Tell us about it.',cateringNote:'Requests are reviewed by the team. Sending an inquiry is not a confirmed booking.',formName:'YOUR NAME',formEmail:'EMAIL ADDRESS',formDate:'EVENT DATE',formGuests:'APPROX. GUESTS',formType:'WHAT ARE YOU PLANNING?',formDetails:'TELL US MORE',optionPrivate:'Private event',optionCorporate:'Company event',optionFestival:'Festival or market',optionOther:'Something else',previewInquiry:'PREVIEW REQUEST',inquiryDisclaimer:'Demo only — no message will be sent.',
      lastCallEyebrow:"CAN'T WAIT FOR THE NEXT STOP?",lastCallTitle:'GET YOUR<br><i>KNOCKOUT.</i>',footerTag:'BOLD DELI. GOOD COMPANY. ON THE MOVE.',
      more:'VIEW DETAILS',soldOut:'UNAVAILABLE',from:'FROM',askPrice:'ASK FOR PRICE',emptyMenu:'More favorites coming soon. Check the official menu for the full lineup.',emptyEvents:'GOOD STOPS<br>ARE COMING.',emptyEventsDesc:'Official dates and places will appear here once announced. Until then, follow Knockout Deli for the latest stops.',timeTBA:'Time to be confirmed',invalidForm:'Enter your name and a valid email address.',previewReady:'Preview ready. No request has been sent. This form needs a confirmed delivery service before launch.',previewSummary:'Event request preview',locationPlaceholder:'LOCATION UPDATES COMING SOON',hoursPlaceholder:"Follow our social channels for today's details.",getDirections:'GET DIRECTIONS'
    },
    es: {
      navMenu:'EL MENÚ',navEvents:'PRÓXIMAS PARADAS',navCatering:'CONTRATA EL TRUCK',navFind:'ENCUÉNTRANOS',orderButton:'PEDIR POR DOORDASH',
      heroLine1:'DELI DE',heroLine2:'NUEVA YORK.',heroLine3:'SOBRE RUEDAS.',heroDescription:'Los favoritos de deli de Nueva York llegan al sur de Florida: grandes sándwiches, mucho sabor y una nueva parada por descubrir.',heroBottom:'BUENA COMIDA DONDEQUIERA QUE ESTEMOS.',exploreMenu:'VER EL MENÚ',findTruck:'BUSCAR EL TRUCK',photoPreview:'FOTOS DE CONCEPTO PARA EL WEBSITE',
      menuKicker:'LO BUENO',menuTitle:'EL GRAN<br><i>EVENTO.</i>',menuIntro:'Clásicos de deli con personalidad. Descubre algunos favoritos del menú.',menuNote:'Vista conceptual · Menú y precios sujetos a confirmación.',filterAll:'TODOS',filterMain:'PLATOS PRINCIPALES',filterBreakfast:'DESAYUNO',filterRingside:'OTROS FAVORITOS',menuFooter:'¿TIENES HAMBRE? AQUÍ HAY SABOR.',
      eventsKicker:'EN MOVIMIENTO',eventTitle:'MÁS QUE UN<br>FOOD TRUCK.<br><i>UNA EXPERIENCIA.</i>',eventsCopy:'Mercados, festivales y encuentros. Aquí podrás ver en qué evento estará el truck.',seeLocation:'VER UBICACIÓN',upcomingLabel:'PRÓXIMOS EVENTOS',eventFoot:'VUELVE PARA VER LA PRÓXIMA PARADA',
      locationKicker:'ENCUENTRA TU PRÓXIMA COMIDA',locationHeading:"DÓNDE<br>ESTAREMOS<span class='heading-period'>.</span>",locationCopy:'El truck se mueve. El sabor lo sigue. Confirma dónde estará antes de salir.',currentStop:'UBICACIÓN ACTUAL',locationButton:'VER ACTUALIZACIONES',
      cateringKicker:'LLEVAMOS EL SABOR',cateringTitle:'HAGAMOS<br><i>UN EVENTO.</i>',cateringIntro:'Fiestas privadas, almuerzos de empresa, festivales y reuniones comunitarias. Cuéntanos qué estás planeando.',cateringNote:'Las solicitudes las revisa el equipo. Una consulta no confirma una reserva.',formName:'TU NOMBRE',formEmail:'CORREO ELECTRÓNICO',formDate:'FECHA DEL EVENTO',formGuests:'NÚMERO APROX. DE PERSONAS',formType:'TIPO DE EVENTO',formDetails:'CUÉNTANOS MÁS',optionPrivate:'Evento privado',optionCorporate:'Evento corporativo',optionFestival:'Festival o mercado',optionOther:'Otro tipo de evento',previewInquiry:'VER SOLICITUD',inquiryDisclaimer:'Demo: no se enviará ningún mensaje.',
      lastCallEyebrow:'¿NO PUEDES ESPERAR?',lastCallTitle:'PIDE TU<br><i>KNOCKOUT.</i>',footerTag:'BUEN DELI. BUENA COMPAÑÍA. EN MOVIMIENTO.',
      more:'VER DETALLES',soldOut:'NO DISPONIBLE',from:'DESDE',askPrice:'CONSULTAR PRECIO',emptyMenu:'Pronto habrá más opciones. Consulta el menú oficial para ver todos los platos.',emptyEvents:'PRÓXIMAS<br>PARADAS.',emptyEventsDesc:'Aquí aparecerán los eventos cuando se anuncien oficialmente. Por ahora, sigue a Knockout Deli para enterarte.',timeTBA:'Horario por confirmar',invalidForm:'Indica tu nombre y un correo válido.',previewReady:'Vista previa lista. No se envió nada. Este formulario necesita una conexión para enviar solicitudes.',previewSummary:'Vista previa de solicitud',locationPlaceholder:'PRÓXIMA UBICACIÓN POR CONFIRMAR',hoursPlaceholder:'Sigue sus redes para ver la ubicación de hoy.',getDirections:'CÓMO LLEGAR'
    }
  };

  let lang='en', filter='all';
  // The public demo is read-only. No edit actions, persistent storage, or admin routes.
  const state=JSON.parse(JSON.stringify(defaultData));
  const phrase=key => phrases[lang][key] || phrases.en[key] || key;
  const price=amount => amount === '' || amount == null || Number.isNaN(Number(amount)) ? phrase('askPrice') : new Intl.NumberFormat(lang==='es'?'es-US':'en-US',{style:'currency',currency:'USD'}).format(Number(amount));
  const imgIsSafe=src => typeof src==='string' && src.startsWith('./assets/') && !src.includes('..');
  const imageTag=(src,alt,className='') => imgIsSafe(src)?`<img class="${className}" src="${esc(src)}" alt="${esc(alt)}" loading="lazy"/>`:'';
  function renderMenu(){
    const list=filter==='all'?state.menu:state.menu.filter(x=>x.category===filter);
    $('#menu-grid').innerHTML=list.length?list.map((item,i)=>{
      const photo=imgIsSafe(item.image)?imageTag(item.image,`Concept image for ${item.name}`):`<span class="placeholder-number" aria-hidden="true">${String(i+1).padStart(2,'0')}</span><span class="placeholder-name">${esc(item.name)}</span>`;
      return `<article class="menu-card" data-menu-id="${esc(item.id)}" tabindex="0" role="button" aria-label="${esc(item.name)}, ${esc(price(item.price))}"><div class="menu-card-visual">${photo}<span class="card-label">${esc(item.category.toUpperCase())}</span>${!item.available?`<span class="card-tag">${phrase('soldOut')}</span>`:''}</div><div class="menu-card-content"><div class="menu-card-top"><h3>${esc(item.name)}</h3><span class="menu-card-price">${esc(price(item.price))}</span></div><p>${esc(item.description||'')}</p><div class="menu-card-footer"><span>${phrase('more')}</span><span>01 / KD</span></div></div></article>`;
    }).join(''):`<div class="events-empty" style="grid-column:1/-1;color:#1b1816"><strong>${phrase('emptyMenu')}</strong></div>`;
    $$('.filter').forEach(b=>{b.classList.toggle('active',b.dataset.filter===filter);b.setAttribute('aria-pressed',String(b.dataset.filter===filter));});
  }
  function formatDate(raw){const date=new Date(raw);if(Number.isNaN(date.getTime()))return null;return {day:new Intl.DateTimeFormat(lang,{day:'2-digit'}).format(date),month:new Intl.DateTimeFormat(lang,{month:'short'}).format(date).toUpperCase(),time:new Intl.DateTimeFormat(lang,{weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}).format(date),timestamp:date.getTime()};}
  function renderEvents(){
    const upcoming=state.events.filter(e=>e.published&&formatDate(e.datetime)&&formatDate(e.datetime).timestamp>=Date.now()-86400000).sort((a,b)=>new Date(a.datetime)-new Date(b.datetime));
    $('#event-counter').textContent=String(upcoming.length).padStart(2,'0');
    $('#events-list').innerHTML=upcoming.length?upcoming.map(e=>{const d=formatDate(e.datetime);const map='https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(e.location);return `<article class="event-item"><div class="event-date"><span>${esc(d.month)}</span><strong>${esc(d.day)}</strong></div><div class="event-body"><h3>${esc(e.name)}</h3><p>${esc(d.time)}</p><p>${esc(e.location)}</p>${e.description?`<p>${esc(e.description)}</p>`:''}<a href="${esc(map)}" target="_blank" rel="noopener noreferrer">${phrase('getDirections')}</a></div>${imgIsSafe(e.image)?imageTag(e.image,`Photo for ${e.name}`,'event-photo'):''}</article>`;}).join(''):`<div class="events-empty"><strong>${phrase('emptyEvents')}</strong><p>${phrase('emptyEventsDesc')}</p></div>`;
  }
  function renderTruck(){const loc=String(state.truck.location||'').trim(), hours=String(state.truck.hours||'').trim();$('#truck-location').textContent=loc||phrase('locationPlaceholder');$('#truck-hours').textContent=hours||phrase('hoursPlaceholder');const link=$('#directions-link');link.href=loc?`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(loc)}`:'https://linktr.ee/knockoutdeli';link.textContent=loc?phrase('getDirections'):phrase('locationButton');}
  function applyLanguage(){root.lang=lang;$$('[data-i18n]').forEach(el=>{const value=phrase(el.dataset.i18n);if(/<br>|<i>|<span/.test(value)&&(['H1','H2','EM'].includes(el.tagName)||el.dataset.i18n?.includes('Title')))el.innerHTML=value;else el.textContent=value;});$('#language-toggle').textContent=lang==='en'?'ES':'EN';$('#language-toggle').setAttribute('aria-label',lang==='en'?'Switch to Spanish':'Cambiar a inglés');renderMenu();renderEvents();renderTruck();}
  function showProduct(id){const item=state.menu.find(x=>x.id===id);if(!item)return;const photo=imgIsSafe(item.image)?imageTag(item.image,item.name,'dialog-photo'):`<div class="dialog-fallback">${esc(item.name)}</div>`;$('#dialog-body').innerHTML=`${photo}<div class="dialog-text"><span class="section-kicker">${esc(item.category.toUpperCase())}</span><h3>${esc(item.name)}</h3><span class="menu-card-price">${esc(price(item.price))}</span><p>${esc(item.description)}</p><a class="button button-red" target="_blank" rel="noopener noreferrer" href="${DOORDASH_URL}">${phrase('orderButton')}</a></div>`;$('#product-dialog').showModal();}
  $('#language-toggle').addEventListener('click',()=>{lang=lang==='en'?'es':'en';applyLanguage();});
  $$('.filter').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.filter;renderMenu();}));
  $('#menu-grid').addEventListener('click',e=>{const card=e.target.closest('[data-menu-id]');if(card)showProduct(card.dataset.menuId);});
  $('#menu-grid').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){const card=e.target.closest('[data-menu-id]');if(card){e.preventDefault();showProduct(card.dataset.menuId);}}});
  $('#dialog-close').addEventListener('click',()=>$('#product-dialog').close());
  $('#product-dialog').addEventListener('click',e=>{if(e.target===$('#product-dialog'))$('#product-dialog').close();});
  $('#event-inquiry-form').addEventListener('submit',e=>{e.preventDefault();const f=e.currentTarget,name=f.elements.name.value.trim(),email=f.elements.email.value.trim();if(!name||!f.elements.email.checkValidity()){$('#form-feedback').textContent=phrase('invalidForm');return;}const summary=[phrase('previewSummary'),`Name: ${name}`,`Email: ${email}`,`Date: ${f.elements.date.value||'TBD'}`,`Guests: ${f.elements.guests.value||'TBD'}`,`Type: ${f.elements.type.value}`,`Details: ${f.elements.message.value||'—'}`].join('\n');$('#form-feedback').textContent=phrase('previewReady')+'\n\n'+summary;});
  const mobileToggle=$('#mobile-menu-toggle'),mobileNav=$('#mobile-navigation');mobileToggle.addEventListener('click',()=>{const open=mobileToggle.getAttribute('aria-expanded')==='true';mobileToggle.setAttribute('aria-expanded',String(!open));mobileNav.hidden=open;});$$('a',mobileNav).forEach(a=>a.addEventListener('click',()=>{mobileNav.hidden=true;mobileToggle.setAttribute('aria-expanded','false');}));
  window.addEventListener('resize',()=>{if(innerWidth>900){mobileNav.hidden=true;mobileToggle.setAttribute('aria-expanded','false');}});
  let raf=false;window.addEventListener('scroll',()=>{if(raf)return;raf=true;requestAnimationFrame(()=>{const d=document.documentElement;$('#reading-progress').style.width=(100*scrollY/Math.max(1,d.scrollHeight-d.clientHeight))+'%';raf=false;});},{passive:true});
  applyLanguage();
})();
