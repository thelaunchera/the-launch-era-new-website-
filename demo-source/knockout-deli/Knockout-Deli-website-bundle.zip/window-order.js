/* KNOCKOUT DELI — DIGITAL MENU CONCEPT.  No orders, payments, messages or personal data are transmitted/stored. */
(() => {
  'use strict';
  const $ = (q, root=document) => root.querySelector(q);
  const $$ = (q, root=document) => [...root.querySelectorAll(q)];
  const clean = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const text = {
    en:{
      navWindow:'ORDER PICKUP',windowKicker:'PICKUP AT THE TRUCK / QR MENU',windowH1:'OPEN.',windowH2:'CHOOSE.',windowH3:'PICK UP.',windowDescription:'Browse the digital menu right here, choose your food and preview your pickup at the window. No PDF or extra app needed.',step1:'OPEN THE MENU',step2:'CHOOSE YOUR FOOD',step3:'PICK UP AT THE WINDOW',buildList:'BROWSE THE MENU',viewList:'VIEW BAG',yourList:'YOUR BAG',windowDisclosure:'CONCEPT DEMO · No order is sent. The truck’s existing QR still opens its Linktree, unchanged.',menuHint:'Add featured items to your bag and choose your pickup flow right here on the website.',askCrew:'ASK ABOUT PRICE',cartTitle:'YOUR BAG.',estimate:'ESTIMATED SUBTOTAL',cartDisclaimer:'Sample prices only. Taxes and modifications not included. This demo cannot submit or charge for orders.',showCrew:'SHOW AT THE WINDOW',empty:'Your bag is empty. Explore the menu and tap ADD on a priced item.',clear:'CLEAR BAG',added:'Added to your bag',handOff:'SHOW YOUR LIST AT THE WINDOW',handOffHelp:'DEMO — NOT AN ORDER. Show these items to the crew to ask about ordering in person; nothing has been submitted, reserved or paid for.',backToList:'EDIT MY BAG',remove:'Remove',lineCount:'items',allItems:'Your selection',priceNote:'Sample price · verify with the truck',
      phoneLabel:'CONTACT PHONE',activationHelp:'Send-to-truck is a proposed feature. It is NOT active until Knockout Deli approves receiving direct orders.',submitInactive:'SEND TO TRUCK · NOT ACTIVE IN DEMO',menuIntegrated:'THE MENU LIVES HERE — NO PDF TO OPEN',menuHow:'Browse the deli favorites, build a bag and choose pickup right here on your phone.',stepBrowse:'BROWSE',stepBag:'YOUR BAG',stepPickup:'PICKUP',orderAhead:'ORDER DIRECT · PAY AT TRUCK',pickupAtWindow:'PICK UP AT WINDOW · NO ONLINE PAYMENT',atTruck:"I'M AT THE TRUCK",showCrewPreview:'SHOW MY SELECTION TO THE CREW',checkoutKicker:'DIGITAL MENU / PICKUP PREVIEW',bag:'BAG',pickup:'PICKUP',review:'REVIEW',continuePickup:'CONTINUE TO PICKUP',choosePickup:'HOW WOULD YOU LIKE TO PICK UP?',aheadWindow:'ORDER DIRECT · PAY AT THE TRUCK',aheadHelp:'Submit a pickup request once the truck activates direct ordering',showAtWindow:"I'M AT THE WINDOW",windowHelp:'Show your selection to the crew in person',pickupName:'PICKUP NAME',pickupWhen:'WHEN WOULD YOU LIKE TO PICK UP?',asap:'AS SOON AS AVAILABLE',chooseTime:'CHOOSE A TIME (PREVIEW)',requestedTime:'REQUESTED TIME',orderNotes:'ORDER NOTES (OPTIONAL)',privacyNote:'Demo only — details stay on this page and are never transmitted or saved.',backBag:'BACK TO BAG',previewPickup:'REVIEW PICKUP PREVIEW',previewAlert:'DEMO — NO ORDER PLACED',previewTitle:'DIRECT PICKUP REQUEST PREVIEW',previewIntro:'This is how your pickup details could look. The food truck has NOT received an order and no payment was taken.',methodLabel:'PICKUP METHOD',nameLabel:'NAME',timeLabel:'PICKUP REQUEST',instructionsLabel:'NOTES',notProvided:'Not entered',asapRequested:'As soon as available (not confirmed)',nowAtWindow:'Present to crew at window',pickupAheadLabel:'Order-ahead / pickup at window',pickupAtTruckLabel:'At truck / show crew',previewEdit:'EDIT PICKUP',demoOnly:'This is a design preview, not an order receipt or confirmation.',nameNeeded:'Enter a name to preview order-ahead pickup.',timeNeeded:'Choose a time to preview a scheduled pickup.',donePreview:'BACK TO MENU'
    },
    es:{
      navWindow:'PEDIR PARA RECOGER',windowKicker:'RECOGER EN LA VENTANILLA / MENÚ QR',windowH1:'ABRE.',windowH2:'ELIGE.',windowH3:'RECOGE.',windowDescription:'Explora el menú digital en esta página, elige tus platos y revisa cómo recogerlos en la ventanilla. Sin PDF ni aplicaciones adicionales.',step1:'ABRE EL MENÚ',step2:'ELIGE TU COMIDA',step3:'RECOGE EN LA VENTANILLA',buildList:'EXPLORAR MENÚ',viewList:'VER CARRITO',yourList:'TU CARRITO',windowDisclosure:'DEMO · No se envían pedidos. Su QR actual sigue abriendo Linktree sin cambios.',menuHint:'Añade tus platos al carrito y elige cómo recogerlos directamente en la página.',askCrew:'CONSULTAR PRECIO',cartTitle:'TU CARRITO.',estimate:'SUBTOTAL ESTIMADO',cartDisclaimer:'Precios de muestra. No incluye impuestos ni modificaciones. Esta demo no cobra ni envía pedidos.',showCrew:'MOSTRAR EN VENTANILLA',empty:'Tu carrito está vacío. Explora el menú y toca AÑADIR en un producto con precio.',clear:'VACIAR CARRITO',added:'Añadido al carrito',handOff:'MUESTRA TU LISTA EN LA VENTANILLA',handOffHelp:'DEMO — NO ES UN PEDIDO. Muestra los productos al personal para consultar cómo pedir; nada se ha enviado, reservado ni pagado.',backToList:'EDITAR CARRITO',remove:'Quitar',lineCount:'productos',allItems:'Tu selección',priceNote:'Precio de muestra · confirmar',
      phoneLabel:'TELÉFONO DE CONTACTO',activationHelp:'Enviar al truck es una función propuesta. No estará activa hasta que Knockout Deli autorice recibir pedidos directos.',submitInactive:'ENVIAR AL TRUCK · NO ACTIVO EN DEMO',menuIntegrated:'EL MENÚ ESTÁ AQUÍ — SIN ABRIR PDF',menuHow:'Explora tus favoritos, arma el carrito y elige la recogida desde el teléfono.',stepBrowse:'EXPLORA',stepBag:'CARRITO',stepPickup:'RECOGE',orderAhead:'PEDIR DIRECTO · PAGAR EN EL TRUCK',pickupAtWindow:'RECOGER EN VENTANILLA · SIN PAGO ONLINE',atTruck:'ESTOY EN EL TRUCK',showCrewPreview:'MOSTRAR SELECCIÓN AL PERSONAL',checkoutKicker:'MENÚ DIGITAL / DEMO DE RECOGIDA',bag:'CARRITO',pickup:'RECOGIDA',review:'REVISAR',continuePickup:'CONTINUAR A RECOGIDA',choosePickup:'¿CÓMO PREFIERES RECOGER?',aheadWindow:'PEDIR DIRECTO · PAGAR EN EL TRUCK',aheadHelp:'Envía una solicitud cuando el negocio active los pedidos directos',showAtWindow:'ESTOY EN LA VENTANILLA',windowHelp:'Muestra tu selección al personal',pickupName:'NOMBRE PARA RECOGER',pickupWhen:'¿CUÁNDO QUIERES RECOGER?',asap:'LO ANTES POSIBLE',chooseTime:'ELEGIR HORA (DEMO)',requestedTime:'HORA SOLICITADA',orderNotes:'NOTAS (OPCIONAL)',privacyNote:'Solo demo: los datos permanecen en la pantalla; no se envían ni guardan.',backBag:'VOLVER AL CARRITO',previewPickup:'REVISAR VISTA PREVIA',previewAlert:'DEMO — NO SE REALIZÓ UN PEDIDO',previewTitle:'VISTA PREVIA DE PEDIDO DIRECTO',previewIntro:'Así se vería tu solicitud. El food truck NO recibió ningún pedido ni se cobró un pago.',methodLabel:'TIPO DE RECOGIDA',nameLabel:'NOMBRE',timeLabel:'HORA SOLICITADA',instructionsLabel:'NOTAS',notProvided:'Sin indicar',asapRequested:'Lo antes posible (sin confirmar)',nowAtWindow:'Mostrar al personal',pickupAheadLabel:'Pedir antes / recoger en ventanilla',pickupAtTruckLabel:'En el truck / mostrar al personal',previewEdit:'EDITAR RECOGIDA',demoOnly:'Esto es una muestra del diseño, no un recibo ni confirmación.',nameNeeded:'Escribe un nombre para revisar la opción de pedir antes.',timeNeeded:'Elige una hora para revisar esa opción.',donePreview:'VOLVER AL MENÚ'
    }
  };

  const directCopy={
    en:{orderRoutes:'TWO WAYS TO ORDER',orderRoutesHelp:'Choose DoorDash to order there, or build a direct pickup request and pay at the truck. This demo cannot send live requests.',orderDoorDash:'ORDER ON DOORDASH ↗',phoneLabel:'CONTACT PHONE (FOR PICKUP UPDATES)',payTruck:'PAY AT THE TRUCK',noStripe:'No Stripe or online payment. The crew would confirm pickup when ordering is activated.'},
    es:{orderRoutes:'DOS FORMAS DE PEDIR',orderRoutesHelp:'Pide desde DoorDash o prepara una solicitud directa para recoger y pagar en el truck. Esta demo no envía solicitudes reales.',orderDoorDash:'PEDIR POR DOORDASH ↗',phoneLabel:'TELÉFONO (PARA AVISOS DE RECOGIDA)',payTruck:'PAGAR EN EL TRUCK',noStripe:'Sin Stripe ni cobros online. El equipo confirmaría la recogida cuando se active el sistema.'}
  };
  const lang=()=>document.documentElement.lang==='es'?'es':'en';
  const t=key=>text[lang()][key]||key;
  const money=amount=>new Intl.NumberFormat(lang()==='es'?'es-US':'en-US',{style:'currency',currency:'USD'}).format(amount);
  const items=new Map();
  const dialog=$('#window-cart-dialog'),stepBag=$('#checkout-edit-stage'),stepPickup=$('#pickup-preview-form'),review=$('#window-review-slip');
  const cartList=$('#window-cart-items'),reviewButton=$('#window-review-button'),pickupName=$('#pickup-demo-name');
  let mode='ahead',stage='bag',toastTimer;

  const total=()=>[...items.values()].reduce((sum,x)=>sum+x.price*x.quantity,0);
  const quantity=()=>[...items.values()].reduce((sum,x)=>sum+x.quantity,0);
  const setWindowMode=()=>{document.body.classList.add('window-mode');$('#window-sticky').hidden=false};
  function updateCount(){
    $('#window-sticky-count').textContent=String(quantity());
    $('#window-sticky-total').textContent=money(total());
    $('#window-sticky-button').setAttribute('aria-label',t('yourList')+' — '+quantity()+' '+t('lineCount'));
  }
  function toast(message){const el=$('#window-toast');el.textContent=message;el.hidden=false;el.classList.remove('pop');void el.offsetWidth;el.classList.add('pop');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.hidden=true,2000);}
  function setMode(value){
    mode=value==='at-truck'?'at-truck':'ahead';
    $$('[data-order-mode]').forEach(b=>{const selected=b.dataset.orderMode===mode;b.classList.toggle('active',selected);b.setAttribute('aria-pressed',String(selected));});
    $$('input[name="method"]',stepPickup).forEach(b=>b.checked=b.value===mode);
    $('#ahead-pickup-fields').hidden=mode==='at-truck';
    setWindowMode();
  }
  function setStage(next){
    stage=next;
    stepBag.hidden=stage!=='bag';
    stepPickup.hidden=stage!=='pickup';
    review.hidden=stage!=='preview';
    for(const x of ['bag','pickup','preview']){$('#checkout-step-'+x).classList.toggle('current',x===stage);}
  }
  function renderBag(){
    const values=[...items.values()];
    cartList.innerHTML=values.length?values.map(item=>`<div class="window-cart-row" data-cart-id="${clean(item.id)}"><div class="window-cart-description"><strong>${clean(item.name)}</strong><span>${money(item.price)} · ${clean(t('priceNote'))}</span></div><div class="window-cart-qty"><button type="button" data-qty-minus="${clean(item.id)}" aria-label="Decrease quantity: ${clean(item.name)}">−</button><span>${item.quantity}</span><button type="button" data-qty-plus="${clean(item.id)}" aria-label="Increase quantity: ${clean(item.name)}">+</button></div><strong>${money(item.quantity*item.price)}</strong></div>`).join(''):`<p class="window-cart-empty">${clean(t('empty'))}</p>`;
    $('#window-cart-total').textContent=money(total());
    reviewButton.disabled=!values.length;
    updateCount();
  }
  function addFromButton(btn){
    const id=String(btn.dataset.addItem||''),name=String(btn.dataset.addName||''),price=Number(btn.dataset.addPrice);
    if(!id||!name||!Number.isFinite(price)||price<0||price>2500)return;
    const current=items.get(id);
    if(current)current.quantity=Math.min(50,current.quantity+1);
    else items.set(id,{id,name,price,quantity:1});
    setWindowMode();updateCount();toast(t('added')+': '+name);
    btn.classList.remove('add-bounce');void btn.offsetWidth;btn.classList.add('add-bounce');
    if($('#product-dialog')?.open)$('#product-dialog').close();
    if(dialog.open){renderBag();setStage('bag');}
  }
  function openBag(){setWindowMode();renderBag();setStage('bag');if(!dialog.open)dialog.showModal();}
  function renderPreview(){
    const data=new FormData(stepPickup),method=data.get('method'),name=String(data.get('name')||'').trim(),timing=data.get('timing'),time=String(data.get('time')||''),notes=String(data.get('notes')||'').trim(),phone=String(data.get('phone')||'').trim();
    if(method==='ahead'&&!name){pickupName.setCustomValidity(t('nameNeeded'));pickupName.reportValidity();pickupName.setCustomValidity('');return;}
    if(method==='ahead'&&timing==='later'&&!time){$('#pickup-time').setCustomValidity(t('timeNeeded'));$('#pickup-time').reportValidity();$('#pickup-time').setCustomValidity('');return;}
    const lineItems=[...items.values()];if(!lineItems.length){setStage('bag');return;}
    const when=method==='at-truck'?t('nowAtWindow'):timing==='later'?time:t('asapRequested');
    review.innerHTML=`<div class="digital-preview-alert" role="alert">${clean(t('previewAlert'))}</div><h3>${clean(t('previewTitle'))}</h3><p class="preview-intro">${clean(t('previewIntro'))}</p><ul class="preview-lines">${lineItems.map(x=>`<li><span><b>${x.quantity} × ${clean(x.name)}</b></span><strong>${money(x.price*x.quantity)}</strong></li>`).join('')}</ul><div class="preview-facts"><p><span>${clean(t('methodLabel'))}</span><strong>${clean(method==='at-truck'?t('pickupAtTruckLabel'):t('pickupAheadLabel'))}</strong></p>${method==='ahead'?`<p><span>${clean(t('nameLabel'))}</span><strong>${clean(name)}</strong></p>${phone?`<p><span>${clean(t('phoneLabel'))}</span><strong>${clean(phone)}</strong></p>`:''}`:''}<p><span>${clean(t('timeLabel'))}</span><strong>${clean(when)}</strong></p>${notes?`<p><span>${clean(t('instructionsLabel'))}</span><strong>${clean(notes)}</strong></p>`:''}</div><div class="window-slip-total"><span>${clean(t('estimate'))}</span><strong>${money(total())}</strong></div><p class="preview-warning">${clean(t('demoOnly'))}</p><p class="preview-activation">${clean(t('activationHelp'))}</p><button type="button" class="button button-red preview-submit-disabled" disabled aria-disabled="true" title="${clean(t('activationHelp'))}">${clean(t('submitInactive'))}</button><div class="preview-actions"><button type="button" class="button button-outline" id="pickup-edit" data-order-i18n="previewEdit">${clean(t('previewEdit'))}</button><button type="button" class="button button-red" id="pickup-done" data-order-i18n="donePreview">${clean(t('donePreview'))}</button></div>`;
    setStage('preview');review.scrollIntoView({block:'nearest',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
  }
  function translate(){
    $$('[data-window-i18n]').forEach(el=>el.textContent=t(el.dataset.windowI18n));
    $$('[data-order-i18n]').forEach(el=>el.textContent=t(el.dataset.orderI18n));
    $$('[data-direct-copy]').forEach(el=>el.textContent=directCopy[lang()][el.dataset.directCopy]||'');
    renderBag();
    if(stage==='preview')setStage('pickup'); // never keep stale translated summary
    if(mode==='at-truck')$('#ahead-pickup-fields').hidden=true;
  }
  document.addEventListener('click',event=>{
    const add=event.target.closest('[data-add-item]');if(add){event.preventDefault();addFromButton(add);return;}
    const switching=event.target.closest('[data-order-mode]');if(switching){setMode(switching.dataset.orderMode);return;}
    if(event.target.closest('#view-window-cart,#menu-view-list,#window-sticky-button')){openBag();return;}
    const plus=event.target.closest('[data-qty-plus]'),minus=event.target.closest('[data-qty-minus]');
    if(plus||minus){const id=plus?.dataset.qtyPlus||minus?.dataset.qtyMinus,item=items.get(id);if(item){item.quantity=Math.max(0,Math.min(50,item.quantity+(plus?1:-1)));if(!item.quantity)items.delete(id);renderBag();}return;}
    if(event.target.closest('#window-cart-close')){dialog.close();return;}
    if(event.target.closest('#window-review-button')){if(!quantity())return;setStage('pickup');if(!pickupName.value&&mode==='ahead')pickupName.focus({preventScroll:true});return;}
    if(event.target.closest('#pickup-back')){setStage('bag');return;}
    if(event.target.closest('#pickup-edit')){setStage('pickup');return;}
    if(event.target.closest('#pickup-done')){dialog.close();$('#menu').scrollIntoView({behavior:'smooth',block:'start'});return;}
    if(event.target.closest('a[href="#window-order"],#start-window-order')){setWindowMode();}
  });
  stepPickup.addEventListener('change',event=>{
    if(event.target.name==='method')setMode(event.target.value);
    if(event.target.name==='timing')$('#pickup-time-field').hidden=event.target.value!=='later';
  });
  stepPickup.addEventListener('submit',event=>{event.preventDefault();renderPreview();});
  dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close();});
  new MutationObserver(translate).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
  // Show bag access once the menu is visible, even when browsing without the physical QR.
  if('IntersectionObserver' in window){new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting))setWindowMode();},{rootMargin:'0px 0px -20% 0px',threshold:.02}).observe($('#menu'));}
  translate();
  const qrMode=new URLSearchParams(location.search).get('window')==='1';
  if(qrMode){setMode('at-truck');if(location.hash==='#window-order'){history.replaceState(null,'',location.pathname+location.search+'#menu');}requestAnimationFrame(()=>$('#menu').scrollIntoView({block:'start'}));}
  if(!matchMedia('(prefers-reduced-motion: reduce)').matches&&'IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>{for(const e of entries){if(e.isIntersecting){e.target.classList.add('in-view');observer.unobserve(e.target);}}},{threshold:.10,rootMargin:'0px 0px -16px 0px'});$$('.reveal-me').forEach(el=>{el.classList.add('will-reveal');observer.observe(el);});}
})();
