/* Knockout Deli prospect concept — customer-facing, no connected ordering, POS, payments, or admin panel. */
(() => {
  'use strict';
  const $ = (q, el=document) => el.querySelector(q);
  const money = n => new Intl.NumberFormat(document.documentElement.lang === 'es' ? 'es-US' : 'en-US', {style:'currency',currency:'USD'}).format(n);
  const escapeText = input => String(input ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const translations = {
    en:{navWindow:'ORDER AT WINDOW',windowKicker:'AT THE SERVICE WINDOW / QR MENU',windowH1:'SCAN.',windowH2:'CHOOSE.',windowH3:'SHOW.',windowDescription:'Already at the truck? Browse the food, build your list and show it to the crew at the window. No app needed.',step1:'SCAN THE QR',step2:'PICK YOUR FOOD',step3:'ORDER AT THE WINDOW',buildList:'BUILD MY LIST',viewList:'VIEW MY LIST',yourList:'MY WINDOW LIST',windowDisclosure:'CONCEPT DEMO · No live order is sent. Confirm prices and availability with the crew at the window.',menuHint:'AT THE TRUCK? Tap ADD on any priced item to build a list for the window.',askCrew:'ASK THE CREW',cartTitle:'YOUR WINDOW LIST',estimate:'ESTIMATED TOTAL',cartDisclaimer:'Concept prices only; taxes and modifications are not included. Nothing has been ordered or paid for.',showCrew:'SHOW LIST AT THE WINDOW',empty:'Nothing in your list yet. Choose an item in the menu and tap ADD.',clear:'CLEAR LIST',added:'Added to your window list',handOff:'SHOW THIS LIST TO THE CREW',handOffHelp:'This is a visual preview, not a submitted order. Tell the crew your choices to order and pay in person.',backToList:'EDIT MY LIST',remove:'Remove',lineCount:'items',allItems:'Your selection',priceNote:'Confirm actual prices with the crew.'},
    es:{navWindow:'PEDIR EN LA VENTANILLA',windowKicker:'EN LA VENTANILLA / MENÚ QR',windowH1:'ESCANEA.',windowH2:'ELIGE.',windowH3:'MUESTRA.',windowDescription:'¿Ya estás frente al truck? Mira el menú, prepara tu selección y muéstrala al equipo en la ventanilla. Sin descargar apps.',step1:'ESCANEA EL QR',step2:'ELIGE TU COMIDA',step3:'PIDE EN LA VENTANILLA',buildList:'ARMAR MI LISTA',viewList:'VER MI LISTA',yourList:'MI LISTA PARA PEDIR',windowDisclosure:'DEMO CONCEPTUAL · No se envía ningún pedido. Confirma precios y disponibilidad con el equipo.',menuHint:'¿ESTÁS FRENTE AL TRUCK? Toca AÑADIR en cualquier plato con precio para preparar tu lista.',askCrew:'PREGUNTA AL EQUIPO',cartTitle:'TU LISTA PARA PEDIR',estimate:'TOTAL ESTIMADO',cartDisclaimer:'Precios ilustrativos; no incluye impuestos ni modificaciones. No se realizó ni cobró ningún pedido.',showCrew:'MOSTRAR LISTA EN VENTANILLA',empty:'Aún no elegiste nada. Selecciona un plato del menú y toca AÑADIR.',clear:'VACIAR LISTA',added:'Añadido a tu lista',handOff:'MUESTRA ESTA LISTA AL EQUIPO',handOffHelp:'Es una vista previa visual, no un pedido enviado. Comunica tus platos para ordenar y pagar en persona.',backToList:'EDITAR LISTA',remove:'Quitar',lineCount:'productos',allItems:'Tu selección',priceNote:'Confirma los precios reales con el equipo.'}
  };
  const items = new Map();
  const lang = () => document.documentElement.lang === 'es' ? 'es' : 'en';
  const t = key => translations[lang()][key] || key;
  const orderDialog = $('#window-cart-dialog');
  const listContainer = $('#window-cart-items');
  const reviewSlip = $('#window-review-slip');
  const reviewBtn = $('#window-review-button');
  const countTargets = [$('#window-sticky-count')];
  let toastTimer;
  const inWindowMode = () => document.body.classList.contains('window-mode');
  const setWindowMode = () => {document.body.classList.add('window-mode');$('#window-sticky').hidden=false;};

  function quantity(){return [...items.values()].reduce((total,item)=>total+item.quantity,0);}
  function total(){return [...items.values()].reduce((sum,item)=>sum+item.price*item.quantity,0);}
  function updateCounts(){countTargets.forEach(el=>el.textContent=String(quantity()));$('#window-sticky-button').setAttribute('aria-label',t('yourList')+' — '+quantity()+' '+t('lineCount'));}
  function toast(msg){const el=$('#window-toast');el.textContent=msg;el.hidden=false;el.classList.remove('pop');void el.offsetWidth;el.classList.add('pop');clearTimeout(toastTimer);toastTimer=setTimeout(()=>{el.hidden=true;},1800);}
  function render(){
    const values=[...items.values()];
    listContainer.innerHTML=values.length ? values.map(item=>`<div class="window-cart-row" data-cart-id="${escapeText(item.id)}"><div class="window-cart-description"><strong>${escapeText(item.name)}</strong><span>${money(item.price)} / ${escapeText(t('priceNote'))}</span></div><div class="window-cart-qty"><button type="button" data-qty-minus="${escapeText(item.id)}" aria-label="Decrease quantity for ${escapeText(item.name)}">−</button><span>${item.quantity}</span><button type="button" data-qty-plus="${escapeText(item.id)}" aria-label="Increase quantity for ${escapeText(item.name)}">+</button></div><strong>${money(item.quantity*item.price)}</strong></div>`).join('') : `<p class="window-cart-empty">${escapeText(t('empty'))}</p>`;
    $('#window-cart-total').textContent=money(total());
    reviewBtn.disabled=values.length===0;
    reviewBtn.hidden=false;
    reviewSlip.hidden=true;
    reviewSlip.innerHTML='';
    updateCounts();
  }
  function addFromButton(btn){
    const id=String(btn.dataset.addItem || '');
    const name=String(btn.dataset.addName || '');
    const price=Number(btn.dataset.addPrice);
    if(!id || !name || !Number.isFinite(price) || price<0)return;
    const current=items.get(id);
    if(current){current.quantity=Math.min(current.quantity+1,50);}else{items.set(id,{id,name,price,quantity:1});}
    setWindowMode();updateCounts();
    toast(`${t('added')}: ${name}`);
    btn.classList.remove('add-bounce');void btn.offsetWidth;btn.classList.add('add-bounce');
    if($('#product-dialog').open) $('#product-dialog').close();
    if(orderDialog.open)render();
  }
  function openCart(){setWindowMode();render();if(!orderDialog.open)orderDialog.showModal();}
  function showCrew(){
    if(!quantity())return;
    const now=[...items.values()];
    reviewSlip.hidden=false;
    reviewSlip.innerHTML=`<div class="window-slip-heading"><small>KNOCKOUT DELI / WINDOW LIST</small><h3>${escapeText(t('handOff'))}</h3></div><ul>${now.map(item=>`<li><strong>${item.quantity} × ${escapeText(item.name)}</strong><span>${money(item.price*item.quantity)}</span></li>`).join('')}</ul><div class="window-slip-total"><span>${escapeText(t('estimate'))}</span><strong>${money(total())}</strong></div><p>${escapeText(t('handOffHelp'))}</p><button type="button" class="button button-dark" id="window-edit-list">${escapeText(t('backToList'))}</button>`;
    reviewBtn.hidden=true;
    reviewSlip.scrollIntoView({block:'nearest',behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});
  }
  function translate(){
    document.querySelectorAll('[data-window-i18n]').forEach(el=>el.textContent=t(el.dataset.windowI18n));
    if(orderDialog.open)render();
    updateCounts();
  }
  document.addEventListener('click',event=>{
    const add=event.target.closest('[data-add-item]');
    if(add){event.preventDefault();addFromButton(add);return;}
    if(event.target.closest('#view-window-cart,#menu-view-list,#window-sticky-button')){event.preventDefault();openCart();return;}
    const plus=event.target.closest('[data-qty-plus]');
    const minus=event.target.closest('[data-qty-minus]');
    if(plus || minus){
      const id=plus?.dataset.qtyPlus||minus?.dataset.qtyMinus;const item=items.get(id);
      if(item){item.quantity=Math.max(0,Math.min(50,item.quantity+(plus?1:-1)));if(!item.quantity)items.delete(id);render();}return;
    }
    if(event.target.closest('#window-cart-close')){orderDialog.close();return;}
    if(event.target.closest('#window-review-button')){showCrew();return;}
    if(event.target.closest('#window-edit-list')){reviewSlip.hidden=true;reviewBtn.hidden=false;return;}
    if(event.target.closest('a[href="#window-order"],#start-window-order')){setWindowMode();}
  });
  orderDialog.addEventListener('click',event=>{if(event.target===orderDialog)orderDialog.close();});
  new MutationObserver(translate).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
  translate();
  const qrMode=new URLSearchParams(location.search).get('window')==='1';
  if(qrMode){
    setWindowMode();
    // This URL is a QR-preview entry, not a live ordering endpoint.
    if(!location.hash)requestAnimationFrame(()=>$('#window-order').scrollIntoView({block:'start'}));
  }
  const observer=matchMedia('(prefers-reduced-motion: reduce)').matches?null:new IntersectionObserver(entries=>{for(const entry of entries){if(entry.isIntersecting){entry.target.classList.add('in-view');observer.unobserve(entry.target);}}},{threshold:.12,rootMargin:'0px 0px -16px 0px'});
  if(observer){document.querySelectorAll('.reveal-me').forEach(el=>{el.classList.add('will-reveal');observer.observe(el);});}
})();
