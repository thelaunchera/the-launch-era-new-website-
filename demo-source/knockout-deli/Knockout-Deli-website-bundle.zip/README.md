# Knockout Deli / client-only website concept

Prepared from the website plan and nine actual source assets in Google Drive. The public-facing site contains no Admin Panel.

## Asset mapping
- 01 hero / 02 menu spread / 03 pastrami preparation / 04 customer experience / 05 breakfast / 06 cheesesteak / 07 DoorDash pickup / 08 original truck photo / transparent Knockout Deli logo.
- Original, full-resolution source files live in Google Drive’s Knockout Deli — Website Assets folder. Website uses individually optimized WebP derivatives.

## Safety
- Events and today's location are unconfirmed and left unannounced.
- Catering form is a preview only and does not send any messages.
- DoorDash is an external order link, not a checkout in this website.
- Product details and prices must be reverified with the business before publication.
- Not a business-owned or official production site. No owner/admin panel, logins or data storage.
- The separate 15 Instagram photos are gifts, not website image assets. The event-photo gift folder is currently empty.

## Test
Run `node --check app.js` and use static Playwright screenshot/smoke QA at 360,390,768,1024,1440px.
